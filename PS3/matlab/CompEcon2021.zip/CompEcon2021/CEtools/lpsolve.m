%% LPSOLVE
%
%  Solves linear programming problem max p'x s.t. x>=0, Ax<=b
%
%  Think of
%   x as levels of n economic activities 
%   b as amounts available of m resources
%   p'x as profit from the n activities
%   Ax as amount of resources required to sustain activity levels x
%
%  Usage
%   [x,fval,lambda,MP,exitflag] = lpsolve(p,A,b)
%  Let
%    n        : number of activities
%    m        : number of resources
%  Input
%    p        : n.1 objective function coefficients
%    A        : m.n resource requirement matrix
%    b        : m.1 vector of resource availabilities
%  Output
%    x        : n.1 optimal activity vector
%    fval     : optimal value of objective
%    lambda   : m.1 shadow prices of resources
%    MP       : n.1 economic marginal profits of activities
%    exitflag : 1 if otimality conditions satisfied, otherwise see linprog
%  Note
%    This function simply reformats data for canonical linear program
%    to conform to the usage of Matlab linear program routine linprog.

%  Copyright(c) 1997-2021
%   Mario J. Miranda - miranda.4@osu.edu

function [x,fval,lambda,MP,surplus,exitflag] = lpsolve(p,A,b)

[x,fval,exitflag,~,lambda] = linprog(-p,A,b);
lambda = lambda.ineqlin;
MP = p-A'*lambda;
surplus = b-A*x;
fval = -fval;
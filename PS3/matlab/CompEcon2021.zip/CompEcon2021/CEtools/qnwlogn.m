%% QNWLOGN
%
%  Discretizes distribution of multivariate (d-dimensional) log normal
%  random vector with 1.d mean vector mu and d.d positive definite log
%  variance matrix logvar.
%
%  Usage
%    [x,w] = qnwlogn(n,mu,logvar)
%  Let
%    d = dimension of random variable
%    N = prod(n) number of nodes and probability weights
%  Input
%    n      : 1.d number of nodes per dimension
%    mu     : 1.d mean vector (default: ones)
%    logvar : d.d positive definite log variance matrix (default: identity matrix)
%  Output
%    x      : N.d discrete mass points
%    w      : N.1 probability weights
%  Note
%    To compute Ef(X) when f is real-valued on Re^d and X is a random
%    vector with mean mu whose logarithm is jointly normally distributed
%    with variance matrix logvar, write a vectorized Matlab function f that
%    returns an m.1 vector when passed an m.d matrix, and execute
%    [x,w]=qnwlogn(m,mu,logvar); Ef=w'*f(x).

%  Copyright(c) 1997-2021
%   Mario J. Miranda - miranda.4@osu.edu
%   Paul L. Fackler  - paul_fackler@ncsu.edu

function [x,w] = qnwlogn(n,mu,logvar)
d = length(n);
if nargin<2, mu = ones(1,d); end
if nargin<3, logvar = eye(d); end
if max(n)==1||max(logvar(:))<=0
  x = mu;
  w = 1;
else
  [x,w] = qnwnorm(n,log(mu)-0.5*diag(logvar)',logvar);
  x = exp(x);
end
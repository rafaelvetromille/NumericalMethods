%% LINDEF
%
%  Defines parameters for linear basis functions and computes standard 
%  breakpoints for linear spline
%
%  Usage
%    [n,a,b,params] = lindef(breaks,evennum)
%    [n,a,b,params] = lindef([a,b],num)
%  Input
%    breaks    : breakpoint sequence
%    evennum   : 1 if breakpoints are evenly spaced, 0 otherwise
%    a         : lower bound of approximation interval
%    b         : upper bound of approximation interval
%    num       : number of evenly spaced breakpoints
%  Output
%    n         : number of basis functions (1 plus the polynomial order)
%    a         : lower bound of approximation interval
%    b         : upper bound of approximation interval
%    params    : cell array containing n, a, b
%  Note: Standard breakpoints are evenly spaced

%  Copyright(c) 1997-2021
%   Mario J. Miranda - miranda.4@osu.edu
%   Paul L. Fackler  - paul_fackler@ncsu.edu

function [n,a,b,params] = lindef(breaks,evennum)

if nargin<1 || isempty(breaks)
  error('LINDEF: Breakpoint information must be passed.')
end
if nargin<2
  evennum = 0;
end

n=length(breaks);
if n<2
  error('LINDEF: Breakpoint sequence must contain at least two elements.')
end
if any(diff(breaks)<=0)
  error('LINDEF: Breakpoint sequence must be increasing.');
end
if evennum~=0
  if length(breaks)==2
    breaks = linspace(breaks(1),breaks(2),evennum)';
  else
    if length(breaks)<2
      error('LINDEF: Breakpoint must have at least two elements.')
    end
    if any(abs(diff(diff((breaks))))>5e-15*mean(abs(breaks)))
      error('LINDEF: Breakpoint sequence is not evenly spaced.')
    end
    evennum = length(breaks);
  end
end

n = length(breaks);
a = breaks(1);
b = breaks(end);
params = {breaks,evennum};